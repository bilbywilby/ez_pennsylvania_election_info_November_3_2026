# Pennsylvania Election Information

Small public-information site for the November 3, 2026 Pennsylvania general
election plus source research. Independent project, **not** an official
resource. Confirm everything at [vote.pa.gov](https://www.pa.gov/agencies/vote.html).

## How it works

```
data/*.json  --->  tools/build_site.py  --->  public/index.html  --->  GitHub Pages
 (facts +            (deterministic)           (generated; do not
  sources)                                      edit by hand)
```

- **One source of truth.** Dates, rules, and links live in `data/`. Each
  deadline is stored as a rule (days before Election Day + clock time) and
  recomputed with the `America/New_York` tz database, so the Nov 1 DST change
  (Election Day is UTC-5, earlier deadlines UTC-4) cannot be mis-typed.
- **Publication gate.** Only items with `status: "verified"` and at least two
  distinct HTTPS sources are rendered.
- **Math checks.** `tools/finance_check.py` tests cash conservation
  (`cash_end ~ cash_start + receipts - disbursed`) and cumulative-receipt
  identities within the sources' rounding tolerance.
- **Non-destructive research inventory.** `tools/research_manifest.py` hashes
  every file in `research/` and reports duplicates without deleting anything.

## Commands

```bash
python -m unittest discover -s tests   # unit tests
python tools/validate.py               # data + math + generated-site gate
python tools/build_site.py             # regenerate public/index.html
python tools/research_manifest.py      # refresh research/MANIFEST.json
python tools/check_links.py            # needs network; also runs daily in CI
bash scripts/verify_env.sh             # repo layout check
```

Requires Python 3.9+ (stdlib only).

## Deployment

`main.yml` -> `static.yml` runs tests and `validate.py`, then publishes
`public/`. `deploy-pages-wiki.yml` handles manual/dispatch Pages + Wiki deploys
(`bash scripts/trigger_dispatch.sh both production`, needs `GH_TOKEN`; Wiki
needs the `WIKI_SYNC_TOKEN` secret). `ci.yml` runs on every push/PR and daily.

## Official information

- [Pennsylvania voting and election information](https://www.pa.gov/agencies/vote.html)
- [Lehigh County Voter Registration and Elections](https://www.lehighcounty.org/Departments/Voter-Registration)
- Research index: [research/README.md](research/README.md) · verification
  notes: [research/VERIFICATION.md](research/VERIFICATION.md)
