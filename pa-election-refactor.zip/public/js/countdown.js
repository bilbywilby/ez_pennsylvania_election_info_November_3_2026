(function () {
  "use strict";
  var rows = document.querySelectorAll("tr[data-deadline]");
  function fmt(ms) {
    if (ms <= 0) return "Passed";
    var m = Math.floor(ms / 60000), d = Math.floor(m / 1440), h = Math.floor((m % 1440) / 60);
    if (d >= 2) return d + " days";
    if (d === 1) return "1 day " + h + " h";
    return h + " h " + (m % 60) + " min";
  }
  function tick() {
    var now = Date.now();
    rows.forEach(function (tr) {
      var t = Date.parse(tr.getAttribute("data-deadline"));
      var el = tr.querySelector(".countdown");
      if (!isNaN(t) && el) {
        el.textContent = fmt(t - now);
        tr.classList.toggle("past", t <= now);
      }
    });
  }
  tick();
  setInterval(tick, 60000);
})();
